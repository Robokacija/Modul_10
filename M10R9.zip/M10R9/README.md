# M10R8_kraj

# Opis

8. radionica izrade regulacije drona.

For more information and products, please refer to [***web***](https://www.robokacija.hr).

## License

This project is licensed under GNU v3.0
