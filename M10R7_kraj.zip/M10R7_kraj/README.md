# M10R7_kraj

# Opis

7. radionica izrade regulacije drona.

Potrebno je namjestiti PID parametre kako bismo dobili stabilnu kontrolu drona.

For more information and products, please refer to [***web***](https://www.robokacija.hr).

## License

This project is licensed under GNU v3.0
